(function(){
"use strict";
/* Site settings. Put your Google Analytics 4 Measurement ID (looks like G-XXXXXXXXXX) in gaId to switch analytics on. */
var CFG={phone:"27787641786",phoneLabel:"078 764 1786",email:"divan@dlhealth.online",gaId:""};
function q(s){return Array.prototype.slice.call(document.querySelectorAll(s));}
q("[data-phone]").forEach(function(a){a.href="https://wa.me/"+CFG.phone;a.textContent=CFG.phoneLabel;});
q("[data-email]").forEach(function(a){a.href="mailto:"+CFG.email;a.textContent=CFG.email;});
q("[data-year]").forEach(function(s){s.textContent=new Date().getFullYear();});

function track(name,params){if(typeof window.gtag==="function"){window.gtag("event",name,params||{});}}
if(CFG.gaId&&navigator.doNotTrack!=="1"){
  var s=document.createElement("script");s.async=true;
  s.src="https://www.googletagmanager.com/gtag/js?id="+encodeURIComponent(CFG.gaId);
  document.head.appendChild(s);
  window.dataLayer=window.dataLayer||[];
  window.gtag=function(){window.dataLayer.push(arguments);};
  window.gtag("js",new Date());window.gtag("config",CFG.gaId);
}
document.addEventListener("click",function(e){
  var a=e.target.closest?e.target.closest("[data-track]"):null;
  if(a){track(a.getAttribute("data-track"));}
});

var f=document.getElementById("f");
if(!f){return;}
var loaded=Date.now(),lastSent=0;
var status=document.getElementById("form-status");
function clean(v){return String(v||"").replace(/[\u0000-\u001f\u007f]+/g," ").replace(/\s+/g," ").trim();}
function cleanMsg(v){return String(v||"").replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g,"").replace(/\n{3,}/g,"\n\n").trim();}
function setErr(id,msg){
  var el=document.getElementById("e-"+id),input=document.getElementById("f-"+id);
  if(el){el.textContent=msg||"";}
  if(input){if(msg){input.setAttribute("aria-invalid","true");}else{input.removeAttribute("aria-invalid");}}
}
function validate(){
  var d={n:clean(f.n.value),c:clean(f.c.value),t:f.t.value,p:clean(f.p.value),m:cleanMsg(f.m.value)};
  var bad=null;
  function fail(id,msg){setErr(id,msg);if(!bad){bad=id;}}
  ["n","c","p","m"].forEach(function(k){setErr(k,"");});
  if(d.n.length<2){fail("n","Please enter your name (at least 2 characters).");}
  else if(d.n.length>80){fail("n","Please keep your name under 80 characters.");}
  if(d.c.length<2){fail("c","Please enter your company name. A company name is needed to book.");}
  else if(d.c.length>100){fail("c","Please keep the company name under 100 characters.");}
  if(!/^\d+$/.test(d.p)||+d.p<1||+d.p>500){fail("p","Please enter a number of people from 1 to 500.");}
  if(d.m.length>500){fail("m","Please keep your message under 500 characters.");}
  else if((d.m.match(/https?:\/\/|www\./gi)||[]).length>0){fail("m","Please remove web links from your message.");}
  return {data:d,bad:bad};
}
["n","c","p","m"].forEach(function(k){
  var el=document.getElementById("f-"+k);
  if(el){el.addEventListener("input",function(){setErr(k,"");});}
});
f.addEventListener("submit",function(e){
  e.preventDefault();
  status.textContent="";
  if(f.website&&f.website.value){return;}
  var r=validate();
  if(r.bad){document.getElementById("f-"+r.bad).focus();return;}
  if(Date.now()-loaded<3000){status.textContent="Please check your details and try again.";return;}
  if(Date.now()-lastSent<8000){status.textContent="Please wait a few seconds before sending again.";return;}
  lastSent=Date.now();
  var d=r.data;
  var t="Hi D&L Health and Safety, I\u2019d like to book a medical.\n"+
    "Name: "+d.n+"\nCompany: "+d.c+"\nMedical type: "+d.t+"\nPeople: "+d.p+(d.m?"\nMessage: "+d.m:"");
  var u="https://wa.me/"+CFG.phone+"?text="+encodeURIComponent(t);
  var o=document.getElementById("wa");
  o.href=u;o.hidden=false;
  status.textContent="Opening WhatsApp. If it does not open, use the button below.";
  track("generate_lead",{method:"whatsapp_form",medical_type:d.t});
  o.click();
});
})();
